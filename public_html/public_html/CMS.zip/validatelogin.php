<?php
session_start();
$username="user";
$password="password";

if(isset($_POST['username']) && isset($_POST['password'])){
    //create a switch case
    
    if(($_POST['username'])==$username && $_POST['password']==$password){
        $_SESSION['loggedin'] = true;
    }
    else{
        //echo "Username or password is incorrect";
        header("location:index.php");
    }
}
if(isset($_SESSION['loggedin']) && $_SESSION['loggedin']==true){
    header("location:loginsuccess.php");
}
?>

<!DOCTYPE html>

<html>
    <head>
        <title>Validating Login.........</title>
    </head>
    
    <body>
        I am in the validating login page....
    </body>
</html>